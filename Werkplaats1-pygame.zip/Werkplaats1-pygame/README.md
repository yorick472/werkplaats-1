# Werkplaats1-pygame
Game beschrijving:

De game is een topdown shooter. Het doel van het spel is om zo veel mogelijk [collectibleitems] te verzamelen voor dat je game over gaat.
de game word moeilijker iedere keer dat de speler [10] punten haalt.
